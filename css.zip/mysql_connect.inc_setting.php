<?php 
$prefix = "";
define("DB_HOSTNAME","localhost");
define("DB_NAME","arina_universe");
define("DB_USERNAME","arinatiger");
define("DB_PASSWORD","arina20031213");
?>